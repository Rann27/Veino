<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark' => ($appearance ?? 'system') == 'dark']); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title inertia><?php echo e(config('app.name', 'Veinovel')); ?></title>

        <link rel="icon" href="/favicon2.ico" sizes="any">
        <link rel="icon" href="/favicon2.ico" type="image/x-icon">
        <link rel="shortcut icon" href="/favicon2.ico">
        <link rel="apple-touch-icon" href="/apple-touch-icon.png">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Google AdSense -->
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6459699146085990"
             crossorigin="anonymous"></script>

        <!-- Theme CSS Custom Properties -->
        <style>
            :root {
                --theme-background: #ffffff;
                --theme-foreground: #000000;
            }
            .theme-loading {
                background-color: var(--theme-background) !important;
                color: var(--theme-foreground) !important;
            }
        </style>

        <!-- Preload Theme Script - Prevents FOUC -->
        <script>
            (function() {
                const themes = {
                    'Light': { background: '#ffffff', foreground: '#000000' },
                    'Dark': { background: '#000000', foreground: '#ffffff' },
                    'Sepia': { background: '#f4ecd8', foreground: '#4b3621' },
                    'Cool Dark': { background: '#1e1e2e', foreground: '#cdd6f4' },
                    'Frost': { background: '#cddced', foreground: '#021a36' },
                    'Solarized': { background: '#fdf6e3', foreground: '#657b83' }
                };

                // Load theme from localStorage immediately
                let currentTheme = themes['Light']; // default
                
                try {
                    // Check cache first
                    const cachedData = localStorage.getItem('veinovel-theme-cache');
                    if (cachedData) {
                        const data = JSON.parse(cachedData);
                        if (themes[data.theme.name]) {
                            currentTheme = themes[data.theme.name];
                        }
                    } else {
                        // Fallback to legacy storage
                        const savedTheme = localStorage.getItem('veinovel-theme');
                        const isSystemTheme = localStorage.getItem('veinovel-system-theme') === 'true';
                        
                        if (isSystemTheme) {
                            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                            currentTheme = prefersDark ? themes['Dark'] : themes['Light'];
                        } else if (savedTheme && themes[savedTheme]) {
                            currentTheme = themes[savedTheme];
                        }
                    }
                } catch (e) {
                    // Error loading, use default
                }

                // Apply theme immediately to CSS custom properties
                document.documentElement.style.setProperty('--theme-background', currentTheme.background);
                document.documentElement.style.setProperty('--theme-foreground', currentTheme.foreground);
                
                // Add class to body for immediate styling
                document.documentElement.className += ' theme-loading';
            })();
        </script>

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased theme-loading" style="background-color: var(--theme-background); color: var(--theme-foreground);">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH F:\0. VeinoMain\Webb\Veino-master\resources\views/app.blade.php ENDPATH**/ ?>